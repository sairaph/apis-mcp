---
title: Overview
page_id: overview
description: |-
    ### Overview

    **The API endpoints documented here are stable. However, the OpenAPI spec used to generate this documentation is unstable. It may change or break without notice.**

    The Tailscale API is a (mostly) RESTful API. Typically, both POST bodies and responses are JSON-encoded.

    ### Base URL

    The base URL for the Tailscale API is https://api.tailscale.com/api/v2/.

    Examples in this document may abbreviate this to `/api/v2/`.

    ### Authentication

    Requests to the Tailscale API are authenticated with an API access token (sometimes called an API key).
    Access tokens can be supplied as the username portion of HTTP Basic authentication
    (leave the password blank) or as an OAuth Bearer token:

    ```sh
    # passing token with basic auth
    curl -u "tskey-api-xxxxx:" https://api.tailscale.com/api/v2/...

    # passing token as bearer token
    curl -H "Authorization: Bearer tskey-api-xxxxx" https://api.tailscale.com/api/v2/...
    ```

    Access tokens for individual users can be created and managed from the [Keys](https://login.tailscale.com/admin/settings/keys) page of the admin console. These tokens will have the same permissions as the owning user, and can be set to expire in 1 to 90 days. Access tokens are identifiable by the prefix tskey-api-.

    Alternatively, a trust credential (OAuth client or federated identity) can be used to create short-lived access tokens with scoped permission. Trust credentials don't expire, and can therefore be used to provide ongoing access to the API, creating access tokens as needed. Trust credentials and the access tokens they create are not tied to an individual Tailscale user. OAuth client secrets are identifiable by the prefix tskey-client-. Learn more about [trust credentials][kb-trust-credentials].

    [kb-trust-credentials]: https://tailscale.com/kb/1623/

    ### Errors

    The Tailscale API returns status codes consistent with standard HTTP conventions. In addition to the status code, errors may include additional information in the response body:

    ```json
    {
      "message": "additional error information"
    }
    ```

    ### Pagination

    The Tailscale API does not currently support pagination. All results are returned at once.
source: https://api.tailscale.com/api/v2?outputOpenapiSchema=true
source_type: openapi
imported_from: https://api.tailscale.com/api/v2?outputOpenapiSchema=true
---

# Tailscale 2026-07-27

### Overview

**The API endpoints documented here are stable. However, the OpenAPI spec used to generate this documentation is unstable. It may change or break without notice.**

The Tailscale API is a (mostly) RESTful API. Typically, both POST bodies and responses are JSON-encoded.

### Base URL

The base URL for the Tailscale API is https://api.tailscale.com/api/v2/.

Examples in this document may abbreviate this to `/api/v2/`.

### Authentication

Requests to the Tailscale API are authenticated with an API access token (sometimes called an API key).
Access tokens can be supplied as the username portion of HTTP Basic authentication
(leave the password blank) or as an OAuth Bearer token:

```sh
# passing token with basic auth
curl -u "tskey-api-xxxxx:" https://api.tailscale.com/api/v2/...

# passing token as bearer token
curl -H "Authorization: Bearer tskey-api-xxxxx" https://api.tailscale.com/api/v2/...
```

Access tokens for individual users can be created and managed from the [Keys](https://login.tailscale.com/admin/settings/keys) page of the admin console. These tokens will have the same permissions as the owning user, and can be set to expire in 1 to 90 days. Access tokens are identifiable by the prefix tskey-api-.

Alternatively, a trust credential (OAuth client or federated identity) can be used to create short-lived access tokens with scoped permission. Trust credentials don't expire, and can therefore be used to provide ongoing access to the API, creating access tokens as needed. Trust credentials and the access tokens they create are not tied to an individual Tailscale user. OAuth client secrets are identifiable by the prefix tskey-client-. Learn more about [trust credentials][kb-trust-credentials].

[kb-trust-credentials]: https://tailscale.com/kb/1623/

### Errors

The Tailscale API returns status codes consistent with standard HTTP conventions. In addition to the status code, errors may include additional information in the response body:

```json
{
  "message": "additional error information"
}
```

### Pagination

The Tailscale API does not currently support pagination. All results are returned at once.

Source: `https://api.tailscale.com/api/v2?outputOpenapiSchema=true`

## Servers

- `https://api.tailscale.com/api/v2`
